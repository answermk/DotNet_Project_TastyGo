using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using FoodDeliver.Models;
using FoodDeliver.Services;
using System.Security.Claims;

namespace FoodDeliver.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FeedbackController : ControllerBase
{
    private readonly IFeedbackService _feedbackService;

    public FeedbackController(IFeedbackService feedbackService)
    {
        _feedbackService = feedbackService;
    }

    [HttpGet]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetAllFeedbacks()
    {
        var feedbacks = await _feedbackService.GetAllFeedbacksAsync();
        return Ok(feedbacks);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetFeedback(string id)
    {
        var feedback = await _feedbackService.GetFeedbackByIdAsync(id);
        if (feedback == null)
        {
            return NotFound();
        }
        return Ok(feedback);
    }

    [HttpGet("user/{userId}")]
    public async Task<IActionResult> GetUserFeedbacks(string userId)
    {
        // Check if the user is authorized to view these feedbacks
        var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (currentUserId != userId && !User.IsInRole("admin"))
        {
            return Forbid();
        }

        var feedbacks = await _feedbackService.GetFeedbacksByUserAsync(userId);
        return Ok(feedbacks);
    }

    [HttpGet("restaurant/{restaurantId}")]
    public async Task<IActionResult> GetRestaurantFeedbacks(string restaurantId)
    {
        var feedbacks = await _feedbackService.GetFeedbacksByRestaurantAsync(restaurantId);
        return Ok(feedbacks);
    }

    [HttpPost]
    [Authorize]
    public async Task<IActionResult> CreateFeedback([FromBody] CreateFeedbackRequest request)
    {
        try
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (userId == null)
            {
                return Unauthorized();
            }

            var feedback = new Feedback
            {
                UserId = userId,
                RestaurantId = request.RestaurantId,
                OrderId = request.OrderId,
                Message = request.Message,
                Rating = request.Rating,
                Status = "new",
                CreatedAt = DateTime.UtcNow
            };

            var createdFeedback = await _feedbackService.CreateFeedbackAsync(feedback);
            return CreatedAtAction(nameof(GetFeedback), new { id = createdFeedback.Id }, createdFeedback);
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPut("{id}/status")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> UpdateFeedbackStatus(string id, [FromBody] UpdateFeedbackStatusRequest request)
    {
        try
        {
            var updatedFeedback = await _feedbackService.UpdateFeedbackStatusAsync(id, request.Status);
            return Ok(updatedFeedback);
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPut("{id}/response")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> AddFeedbackResponse(string id, [FromBody] AddFeedbackResponseRequest request)
    {
        try
        {
            var updatedFeedback = await _feedbackService.AddFeedbackResponseAsync(id, request.Response);
            return Ok(updatedFeedback);
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpGet("status/{status}")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetFeedbacksByStatus(string status)
    {
        var feedbacks = await _feedbackService.GetFeedbacksByStatusAsync(status);
        return Ok(feedbacks);
    }

    [HttpGet("restaurant/{restaurantId}/rating")]
    public async Task<IActionResult> GetRestaurantRating(string restaurantId)
    {
        var rating = await _feedbackService.GetAverageRatingAsync(restaurantId);
        return Ok(new { rating });
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> DeleteFeedback(string id)
    {
        var success = await _feedbackService.DeleteFeedbackAsync(id);
        if (!success)
        {
            return NotFound();
        }
        return NoContent();
    }

    [HttpGet("analytics")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetFeedbackAnalytics()
    {
        var analytics = new
        {
            totalFeedbacks = await _feedbackService.GetTotalFeedbacksCountAsync(),
            averageRating = await _feedbackService.GetAverageRatingAsync(),
            satisfactionRate = await _feedbackService.GetSatisfactionRateAsync(),
            statusBreakdown = await _feedbackService.GetFeedbackStatusBreakdownAsync(),
            recentFeedbacks = await _feedbackService.GetRecentFeedbacksAsync(10)
        };
        return Ok(analytics);
    }

    [HttpGet("unread")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetUnreadFeedbacks()
    {
        var feedbacks = await _feedbackService.GetFeedbacksByStatusAsync("new");
        return Ok(feedbacks);
    }
}

public class CreateFeedbackRequest
{
    public string RestaurantId { get; set; } = string.Empty;
    public string? OrderId { get; set; }
    public string Message { get; set; } = string.Empty;
    public int? Rating { get; set; }
}

public class UpdateFeedbackStatusRequest
{
    public string Status { get; set; } = string.Empty;
}

public class AddFeedbackResponseRequest
{
    public string Response { get; set; } = string.Empty;
} 