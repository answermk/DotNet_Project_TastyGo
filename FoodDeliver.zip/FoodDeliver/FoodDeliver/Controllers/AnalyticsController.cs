using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using FoodDeliver.Services.Interfaces;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using FoodDeliver.Services;

namespace FoodDeliver.Controllers
{
    [Authorize(Roles = "Admin")]
    [ApiController]
    [Route("api/[controller]")]
    public class AnalyticsController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private readonly IFeedbackService _feedbackService;
        private readonly IRestaurantService _restaurantService;
        private readonly IUserService _userService;
        private readonly IReportService _reportService;

        public AnalyticsController(
            IOrderService orderService,
            IFeedbackService feedbackService,
            IRestaurantService restaurantService,
            IUserService userService,
            IReportService reportService)
        {
            _orderService = orderService;
            _feedbackService = feedbackService;
            _restaurantService = restaurantService;
            _userService = userService;
            _reportService = reportService;
        }

        [HttpGet("dashboard")]
        public async Task<IActionResult> GetDashboardAnalytics()
        {
            try
            {
                var startDate = DateTime.UtcNow.AddMonths(-1);
                var endDate = DateTime.UtcNow;

                var totalOrders = await _orderService.GetOrderCountAsync(startDate, endDate);
                var totalRevenue = await _orderService.GetTotalRevenueAsync();
                var totalCustomers = await _userService.GetTotalUsersCountAsync();
                var pendingOrders = await _orderService.GetOrdersByStatusCountAsync("Pending");

                return Ok(new
                {
                    TotalOrders = totalOrders,
                    TotalRevenue = totalRevenue,
                    TotalCustomers = totalCustomers,
                    PendingOrders = pendingOrders
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving dashboard analytics", error = ex.Message });
            }
        }

        [HttpGet("revenue")]
        public async Task<IActionResult> GetRevenueAnalytics([FromQuery] DateTime? startDate, [FromQuery] DateTime? endDate)
        {
            try
            {
                var start = startDate ?? DateTime.UtcNow.AddMonths(-1);
                var end = endDate ?? DateTime.UtcNow;

                var monthlyRevenue = await _orderService.GetMonthlyRevenueAsync();
                var targetRevenue = 1000000; // 1M monthly target

                return Ok(new
                {
                    MonthlyRevenue = monthlyRevenue,
                    TargetRevenue = targetRevenue,
                    AchievementRate = (monthlyRevenue / targetRevenue) * 100
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving revenue analytics", error = ex.Message });
            }
        }

        [HttpGet("orders")]
        public async Task<IActionResult> GetOrderAnalytics()
        {
            try
            {
                var orderStatusBreakdown = await _orderService.GetOrdersStatusBreakdownAsync();
                var completionRate = await _orderService.GetOrderCompletionRateAsync();

                return Ok(new
                {
                    StatusBreakdown = orderStatusBreakdown,
                    CompletionRate = completionRate
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving order analytics", error = ex.Message });
            }
        }

        [HttpGet("satisfaction")]
        public async Task<IActionResult> GetSatisfactionAnalytics()
        {
            try
            {
                var averageRating = await _feedbackService.GetAverageRatingAsync();
                var satisfactionRate = await _feedbackService.GetSatisfactionRateAsync();
                var feedbackStatusBreakdown = await _feedbackService.GetFeedbackStatusBreakdownAsync();

                return Ok(new
                {
                    AverageRating = averageRating,
                    SatisfactionRate = satisfactionRate,
                    StatusBreakdown = feedbackStatusBreakdown
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving satisfaction analytics", error = ex.Message });
            }
        }

        [HttpGet("restaurants")]
        public async Task<IActionResult> GetRestaurantAnalytics([FromQuery] DateTime? startDate, [FromQuery] DateTime? endDate)
        {
            try
            {
                var start = startDate ?? DateTime.UtcNow.AddMonths(-1);
                var end = endDate ?? DateTime.UtcNow;

                var popularRestaurants = await _orderService.GetPopularRestaurantsAsync(start, end);

                return Ok(new
                {
                    PopularRestaurants = popularRestaurants
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving restaurant analytics", error = ex.Message });
            }
        }

        [HttpGet("customers")]
        public async Task<IActionResult> GetCustomerAnalytics()
        {
            try
            {
                var totalUsers = await _userService.GetTotalUsersCountAsync();
                var activeUsers = await _userService.GetActiveUsersCountAsync();
                var newUsers = await _userService.GetNewUsersCountAsync(DateTime.UtcNow.AddMonths(-1));

                return Ok(new
                {
                    TotalUsers = totalUsers,
                    ActiveUsers = activeUsers,
                    NewUsers = newUsers
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving customer analytics", error = ex.Message });
            }
        }

        [HttpGet("reports")]
        public async Task<IActionResult> GenerateReport([FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
        {
            try
            {
                var reportBytes = await _reportService.GenerateReportAsync(startDate, endDate);
                return File(reportBytes, "application/pdf", $"report_{startDate:yyyyMMdd}_{endDate:yyyyMMdd}.pdf");
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error generating report", error = ex.Message });
            }
        }
    }
}
