using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using FoodDeliver.Models;
using FoodDeliver.Services;

namespace FoodDeliver.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RestaurantController : ControllerBase
{
    private readonly IRestaurantService _restaurantService;

    public RestaurantController(IRestaurantService restaurantService)
    {
        _restaurantService = restaurantService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAllRestaurants()
    {
        var restaurants = await _restaurantService.GetAllRestaurantsAsync();
        return Ok(restaurants);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetRestaurant(string id)
    {
        var restaurant = await _restaurantService.GetRestaurantByIdAsync(id);
        if (restaurant == null)
        {
            return NotFound();
        }
        return Ok(restaurant);
    }

    [HttpPost]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> CreateRestaurant([FromBody] Restaurant restaurant)
    {
        var createdRestaurant = await _restaurantService.CreateRestaurantAsync(restaurant);
        return CreatedAtAction(nameof(GetRestaurant), new { id = createdRestaurant.Id }, createdRestaurant);
    }

    [HttpPut("{id}")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> UpdateRestaurant(string id, [FromBody] Restaurant restaurant)
    {
        try
        {
            var updatedRestaurant = await _restaurantService.UpdateRestaurantAsync(id, restaurant);
            return Ok(updatedRestaurant);
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpDelete("{id}")]
    //[Authorize(Roles = "admin")]
    public async Task<IActionResult> DeleteRestaurant(string id)
    {
        var success = await _restaurantService.DeleteRestaurantAsync(id);
        if (!success)
        {
            return NotFound();
        }
        return NoContent();
    }

    [HttpPut("{id}/status")]
    //[Authorize(Roles = "admin")]
    public async Task<IActionResult> UpdateRestaurantStatus(string id, [FromBody] UpdateStatusRequest request)
    {
        var success = await _restaurantService.UpdateRestaurantStatusAsync(id, request.Status == "active");
        if (!success)
        {
            return NotFound();
        }
        return Ok();
    }

    [HttpGet("{id}/menu")]
    public async Task<IActionResult> GetRestaurantMenu(string id)
    {
        var menuItems = await _restaurantService.GetRestaurantMenuItemsAsync(id);
        return Ok(menuItems);
    }

    [HttpGet("{id}/orders")]
    //[Authorize(Roles = "admin")]
    public async Task<IActionResult> GetRestaurantOrders(string id)
    {
        var orders = await _restaurantService.GetRestaurantOrdersAsync(id);
        return Ok(orders);
    }

    [HttpGet("{id}/feedbacks")]
    public async Task<IActionResult> GetRestaurantFeedbacks(string id)
    {
        var feedbacks = await _restaurantService.GetRestaurantFeedbacksAsync(id);
        return Ok(feedbacks);
    }

    [HttpGet("{id}/rating")]
    public async Task<IActionResult> GetRestaurantRating(string id)
    {
        var rating = await _restaurantService.UpdateRestaurantRatingAsync(id);
        return Ok(new { rating });
    }

    [HttpGet("analytics")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetRestaurantAnalytics()
    {
        var analytics = new
        {
            totalRestaurants = await _restaurantService.GetTotalRestaurantsCountAsync(),
            activeRestaurants = await _restaurantService.GetActiveRestaurantsCountAsync(),
            topPerforming = await _restaurantService.GetTopPerformingRestaurantsAsync(),
            averageRating = await _restaurantService.GetAverageRatingAsync()
        };
        return Ok(analytics);
    }

    [HttpGet("performance")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetRestaurantPerformance([FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
    {
        var performance = await _restaurantService.GetRestaurantPerformanceAsync(startDate, endDate);
        return Ok(performance);
    }
}

public class UpdateStatusRequest
{
    public string Status { get; set; } = string.Empty;
} 