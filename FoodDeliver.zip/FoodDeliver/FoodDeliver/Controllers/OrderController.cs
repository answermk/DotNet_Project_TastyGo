using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using FoodDeliver.Models;
using FoodDeliver.Models.DTOs;
using FoodDeliver.Services;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using FoodDeliver.Data;

namespace FoodDeliver.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class OrderController : ControllerBase
{
    private readonly IOrderService _orderService;
    private readonly AppDbContext _context;

    public OrderController(IOrderService orderService, AppDbContext context)
    {
        _orderService = orderService;
        _context = context;
    }

    [HttpGet]
    [Authorize(Roles = "admin")]
    public async Task<ActionResult<IEnumerable<OrderResponse>>> GetAllOrders()
    {
        var orders = await _orderService.GetAllOrdersAsync();
        return Ok(orders.Select(o => MapToOrderResponse(o)));
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<OrderResponse>> GetOrder(string id)
    {
        var order = await _orderService.GetOrderByIdAsync(id);
        if (order == null)
        {
            return NotFound();
        }

        // Check if the user is authorized to view this order
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (userId != order.UserId && !User.IsInRole("admin"))
        {
            return Forbid();
        }

        return Ok(MapToOrderResponse(order));
    }

    [HttpGet("user/{userId}")]
    public async Task<ActionResult<IEnumerable<OrderResponse>>> GetUserOrders(string userId)
    {
        // Check if the user is authorized to view these orders
        var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (currentUserId != userId && !User.IsInRole("admin"))
        {
            return Forbid();
        }

        var orders = await _orderService.GetOrdersByUserAsync(userId);
        return Ok(orders.Select(o => MapToOrderResponse(o)));
    }

    [HttpGet("restaurant/{restaurantId}")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetRestaurantOrders(string restaurantId)
    {
        var orders = await _orderService.GetOrdersByRestaurantAsync(restaurantId);
        return Ok(orders);
    }

    [HttpPost]
    public async Task<ActionResult<OrderResponse>> CreateOrder([FromBody] CreateOrderRequest request)
    {
        try
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (userId == null)
            {
                return Unauthorized();
            }

            var order = new Order
            {
                UserId = userId,
                RestaurantId = request.RestaurantId,
                DeliveryAddress = request.DeliveryAddress,
                PaymentMethod = request.PaymentMethod,
                Status = "pending",
                PaymentStatus = request.PaymentMethod == "momo-pay" ? "completed" : "pending",
                CreatedAt = DateTime.UtcNow
            };

            // Map DTOs to OrderItem entities
            var orderItems = request.OrderItems.Select(item => new OrderItem
            {
                MenuItemId = item.MenuItemId,
                Quantity = item.Quantity
            }).ToList();

            var createdOrder = await _orderService.CreateOrderAsync(order, orderItems);
            return CreatedAtAction(nameof(GetOrder), new { id = createdOrder.Id }, MapToOrderResponse(createdOrder));
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPut("{id}/status")]
    [Authorize(Roles = "admin")]
    public async Task<ActionResult<OrderResponse>> UpdateOrderStatus(string id, [FromBody] UpdateOrderStatusRequest request)
    {
        try
        {
            var updatedOrder = await _orderService.UpdateOrderStatusAsync(id, request.Status);
            return Ok(MapToOrderResponse(updatedOrder));
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPut("{id}/payment")]
    [Authorize(Roles = "admin")]
    public async Task<ActionResult<OrderResponse>> UpdatePaymentStatus(string id, [FromBody] UpdatePaymentStatusRequest request)
    {
        try
        {
            var updatedOrder = await _orderService.UpdatePaymentStatusAsync(id, request.Status);
            return Ok(MapToOrderResponse(updatedOrder));
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPost("{id}/cancel")]
    public async Task<IActionResult> CancelOrder(string id)
    {
        var order = await _orderService.GetOrderByIdAsync(id);
        if (order == null)
        {
            return NotFound();
        }

        // Check if the user is authorized to cancel this order
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (userId != order.UserId && !User.IsInRole("admin"))
        {
            return Forbid();
        }

        var success = await _orderService.CancelOrderAsync(id);
        if (!success)
        {
            return BadRequest(new { message = "Order cannot be cancelled" });
        }

        return Ok();
    }

    [HttpGet("status/{status}")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetOrdersByStatus(string status)
    {
        var orders = await _orderService.GetOrdersByStatusAsync(status);
        return Ok(orders);
    }

    [HttpGet("stats")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetOrderStats([FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
    {
        var revenue = await _orderService.GetTotalRevenueAsync(startDate, endDate);
        var count = await _orderService.GetOrderCountAsync(startDate, endDate);
        return Ok(new { revenue, count });
    }

    [HttpGet("analytics")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetOrderAnalytics()
    {
        var analytics = new
        {
            totalOrders = await _orderService.GetTotalOrdersCountAsync(),
            totalRevenue = await _orderService.GetTotalRevenueAsync(),
            pendingOrders = await _orderService.GetOrdersByStatusCountAsync("pending"),
            statusBreakdown = await _orderService.GetOrdersStatusBreakdownAsync(),
            monthlyRevenue = await _orderService.GetMonthlyRevenueAsync(),
            completionRate = await _orderService.GetOrderCompletionRateAsync(),
            popularRestaurants = await _orderService.GetPopularRestaurantsAsync(DateTime.UtcNow.AddDays(-30), DateTime.UtcNow)
        };
        return Ok(analytics);
    }

    [HttpGet("popular-restaurants")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetPopularRestaurants([FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
    {
        var restaurants = await _orderService.GetPopularRestaurantsAsync(startDate, endDate);
        return Ok(restaurants);
    }

    [HttpGet("customer/{userId}")]
    public async Task<IActionResult> GetOrdersByCustomer(string userId)
    {
        var orders = await _context.Orders
            .Where(o => o.UserId == userId)
            .ToListAsync();
        return Ok(orders);
    }

    private OrderResponse MapToOrderResponse(Order order)
    {
        return new OrderResponse
        {
            Id = order.Id,
            UserId = order.UserId,
            RestaurantId = order.RestaurantId,
            RestaurantName = order.Restaurant?.Name ?? string.Empty,
            Status = order.Status,
            Total = order.Total,
            DeliveryAddress = order.DeliveryAddress,
            PaymentMethod = order.PaymentMethod,
            PaymentStatus = order.PaymentStatus,
            CreatedAt = order.CreatedAt,
            UpdatedAt = order.UpdatedAt,
            Items = order.OrderItems.Select(oi => new OrderItemResponse
            {
                Id = oi.Id,
                MenuItemId = oi.MenuItemId,
                Name = oi.MenuItem?.Name ?? string.Empty,
                Price = oi.Price,
                Quantity = oi.Quantity,
                SpecialInstructions = oi.SpecialInstructions
            })
        };
    }
}

// DTOs for order creation
public class CreateOrderItemRequest
{
    public string MenuItemId { get; set; }
    public int Quantity { get; set; }
}

public class CreateOrderRequest
{
    public string RestaurantId { get; set; } = string.Empty;
    public string DeliveryAddress { get; set; } = string.Empty;
    public string PaymentMethod { get; set; } = string.Empty;
    public IEnumerable<CreateOrderItemRequest> OrderItems { get; set; } = new List<CreateOrderItemRequest>();
}

public class UpdateOrderStatusRequest
{
    public string Status { get; set; } = string.Empty;
}

public class UpdatePaymentStatusRequest
{
    public string Status { get; set; } = string.Empty;
} 