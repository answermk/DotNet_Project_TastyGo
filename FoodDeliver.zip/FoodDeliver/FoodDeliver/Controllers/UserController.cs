using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using FoodDeliver.Models;
using FoodDeliver.Services;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using FoodDeliver.Data;

namespace FoodDeliver.Controllers;

[ApiController]
[Route("api/[controller]")]
//[Authorize]
public class UserController : ControllerBase
{
    private readonly IUserService _userService;
    private readonly IWebHostEnvironment _environment;
    private readonly AppDbContext _context;

    public UserController(IUserService userService, IWebHostEnvironment environment, AppDbContext context)
    {
        _userService = userService;
        _environment = environment;
        _context = context;
    }

    [HttpGet]
    //[Authorize(Roles = "admin")]
    public async Task<IActionResult> GetAllUsers()
    {
        var users = await _userService.GetAllUsersAsync();
        return Ok(users);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetUser(string id)
    {
        // Check if the user is authorized to view this user
        var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (currentUserId != id && !User.IsInRole("admin"))
        {
            return Forbid();
        }

        var user = await _userService.GetUserByIdAsync(id);
        if (user == null)
        {
            return NotFound();
        }
        return Ok(user);
    }

    [HttpPost]
    //[Authorize(Roles = "admin")]
    public async Task<IActionResult> CreateUser([FromBody] User user)
    {
        var createdUser = await _userService.CreateUserAsync(user);
        return CreatedAtAction(nameof(GetUser), new { id = createdUser.Id }, createdUser);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateUser(string id, [FromBody] User user)
    {
        // Check if the user is authorized to update this user
        var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (currentUserId != id && !User.IsInRole("admin"))
        {
            return Forbid();
        }

        try
        {
            var updatedUser = await _userService.UpdateUserAsync(id, user);
            return Ok(updatedUser);
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpDelete("{id}")]
    //[Authorize(Roles = "admin")]
    public async Task<IActionResult> DeleteUser(string id)
    {
        var success = await _userService.DeleteUserAsync(id);
        if (!success)
        {
            return NotFound();
        }
        return NoContent();
    }

    [HttpPut("{id}/status")]
    //[Authorize(Roles = "admin")]
    public async Task<IActionResult> UpdateUserStatus(string id, [FromBody] UpdateStatusRequest request)
    {
        var success = await _userService.UpdateUserStatusAsync(id, request.Status);
        if (!success)
        {
            return NotFound();
        }
        return Ok();
    }

    [HttpGet("{id}/orders")]
    public async Task<IActionResult> GetUserOrders(string id)
    {
        // Check if the user is authorized to view these orders
        var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (currentUserId != id && !User.IsInRole("admin"))
        {
            return Forbid();
        }

        var orders = await _userService.GetUserOrdersAsync(id);
        return Ok(orders);
    }

    [HttpGet("{id}/feedbacks")]
    public async Task<IActionResult> GetUserFeedbacks(string id)
    {
        // Check if the user is authorized to view these feedbacks
        var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (currentUserId != id && !User.IsInRole("admin"))
        {
            return Forbid();
        }

        var feedbacks = await _userService.GetUserFeedbacksAsync(id);
        return Ok(feedbacks);
    }

    [HttpPost("photo")]
    public async Task<IActionResult> UploadPhoto(IFormFile photo)
    {
        if (photo == null || photo.Length == 0)
        {
            return BadRequest(new { message = "No file uploaded" });
        }

        // Validate file type
        if (!photo.ContentType.StartsWith("image/"))
        {
            return BadRequest(new { message = "Only image files are allowed" });
        }

        // Validate file size (max 5MB)
        if (photo.Length > 5 * 1024 * 1024)
        {
            return BadRequest(new { message = "File size should be less than 5MB" });
        }

        try
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (userId == null)
            {
                return Unauthorized();
            }

            // Create uploads directory if it doesn't exist
            var uploadsDir = Path.Combine(_environment.WebRootPath, "uploads", "profile-photos");
            if (!Directory.Exists(uploadsDir))
            {
                Directory.CreateDirectory(uploadsDir);
            }

            // Generate unique filename
            var fileName = $"{userId}_{DateTime.UtcNow:yyyyMMddHHmmss}{Path.GetExtension(photo.FileName)}";
            var filePath = Path.Combine(uploadsDir, fileName);

            // Save file
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await photo.CopyToAsync(stream);
            }

            // Update user's avatar URL
            var avatarUrl = $"/uploads/profile-photos/{fileName}";
            var user = await _userService.GetUserByIdAsync(userId);
            if (user != null)
            {
                user.Avatar = avatarUrl;
                await _userService.UpdateUserAsync(userId, user);
            }

            return Ok(new { avatar = avatarUrl });
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = "Failed to upload photo: " + ex.Message });
        }
    }

    [HttpGet("users")]
    public async Task<IActionResult> GetUsers()
    {
        var users = await _context.Users.ToListAsync();
        return Ok(users);
    }
}

/*public class UpdateStatusRequest
{
    public string Status { get; set; } = string.Empty;
} */