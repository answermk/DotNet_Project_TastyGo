using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using FoodDeliver.Models;
using FoodDeliver.Services;

namespace FoodDeliver.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MenuController : ControllerBase
{
    private readonly IMenuService _menuService;

    public MenuController(IMenuService menuService)
    {
        _menuService = menuService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAllMenuItems()
    {
        var menuItems = await _menuService.GetAllMenuItemsAsync();
        return Ok(menuItems);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetMenuItem(string id)
    {
        var menuItem = await _menuService.GetMenuItemByIdAsync(id);
        if (menuItem == null)
        {
            return NotFound();
        }
        return Ok(menuItem);
    }

    [HttpGet("restaurant/{restaurantId}")]
    public async Task<IActionResult> GetRestaurantMenu(string restaurantId)
    {
        var menuItems = await _menuService.GetMenuItemsByRestaurantAsync(restaurantId);
        return Ok(menuItems);
    }

    //[Authorize(Roles = "admin")]
    [HttpPost]
    public async Task<IActionResult> CreateMenuItem([FromBody] MenuItem menuItem)
    {
        var createdMenuItem = await _menuService.CreateMenuItemAsync(menuItem);
        return CreatedAtAction(nameof(GetMenuItem), new { id = createdMenuItem.Id }, createdMenuItem);
    }

    [Authorize(Roles = "admin")]
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateMenuItem(string id, [FromBody] MenuItem menuItem)
    {
        try
        {
            var updatedMenuItem = await _menuService.UpdateMenuItemAsync(id, menuItem);
            return Ok(updatedMenuItem);
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    //[Authorize(Roles = "admin")]
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteMenuItem(string id)
    {
        var success = await _menuService.DeleteMenuItemAsync(id);
        if (!success)
        {
            return NotFound();
        }
        return NoContent();
    }

    //[Authorize(Roles = "admin")]
    [HttpPut("{id}/availability")]
    public async Task<IActionResult> UpdateMenuItemAvailability(string id, [FromBody] UpdateAvailabilityRequest request)
    {
        var success = await _menuService.UpdateMenuItemAvailabilityAsync(id, request.IsAvailable);
        if (!success)
        {
            return NotFound();
        }
        return Ok();
    }

    [HttpGet("restaurant/{restaurantId}/category/{category}")]
    public async Task<IActionResult> GetMenuItemsByCategory(string restaurantId, string category)
    {
        var menuItems = await _menuService.GetMenuItemsByCategoryAsync(restaurantId, category);
        return Ok(menuItems);
    }

    [HttpGet("restaurant/{restaurantId}/categories")]
    public async Task<IActionResult> GetMenuCategories(string restaurantId)
    {
        var categories = await _menuService.GetMenuCategoriesAsync(restaurantId);
        return Ok(categories);
    }
}

public class UpdateAvailabilityRequest
{
    public bool IsAvailable { get; set; }
} 