using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using FoodDeliver.Services;

namespace FoodDeliver.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "admin")]
public class ReportController : ControllerBase
{
    private readonly IReportService _reportService;

    public ReportController(IReportService reportService)
    {
        _reportService = reportService;
    }

    [HttpGet("orders")]
    public async Task<IActionResult> GenerateOrdersReport(
        [FromQuery] DateTime startDate,
        [FromQuery] DateTime endDate,
        [FromQuery] string format = "excel")
    {
        try
        {
            var reportBytes = await _reportService.GenerateOrdersReportAsync(startDate, endDate, format);
            return File(reportBytes, GetContentType(format), $"orders-report-{DateTime.UtcNow:yyyyMMdd}.{format}");
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpGet("users")]
    public async Task<IActionResult> GenerateUsersReport(
        [FromQuery] DateTime startDate,
        [FromQuery] DateTime endDate,
        [FromQuery] string format = "excel")
    {
        try
        {
            var reportBytes = await _reportService.GenerateUsersReportAsync(startDate, endDate, format);
            return File(reportBytes, GetContentType(format), $"users-report-{DateTime.UtcNow:yyyyMMdd}.{format}");
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpGet("restaurants")]
    public async Task<IActionResult> GenerateRestaurantsReport(
        [FromQuery] DateTime startDate,
        [FromQuery] DateTime endDate,
        [FromQuery] string format = "excel")
    {
        try
        {
            var reportBytes = await _reportService.GenerateRestaurantsReportAsync(startDate, endDate, format);
            return File(reportBytes, GetContentType(format), $"restaurants-report-{DateTime.UtcNow:yyyyMMdd}.{format}");
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpGet("feedback")]
    public async Task<IActionResult> GenerateFeedbackReport(
        [FromQuery] DateTime startDate,
        [FromQuery] DateTime endDate,
        [FromQuery] string format = "excel")
    {
        try
        {
            var reportBytes = await _reportService.GenerateFeedbackReportAsync(startDate, endDate, format);
            return File(reportBytes, GetContentType(format), $"feedback-report-{DateTime.UtcNow:yyyyMMdd}.{format}");
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpGet("analytics")]
    public async Task<IActionResult> GenerateAnalyticsReport(
        [FromQuery] DateTime startDate,
        [FromQuery] DateTime endDate,
        [FromQuery] string format = "excel")
    {
        try
        {
            var reportBytes = await _reportService.GenerateAnalyticsReportAsync(startDate, endDate, format);
            return File(reportBytes, GetContentType(format), $"analytics-report-{DateTime.UtcNow:yyyyMMdd}.{format}");
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    private string GetContentType(string format)
    {
        return format.ToLower() switch
        {
            "csv" => "text/csv",
            "excel" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "pdf" => "application/pdf",
            _ => "application/octet-stream"
        };
    }
} 