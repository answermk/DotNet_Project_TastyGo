using OfficeOpenXml;
using CsvHelper;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using System.Text;
using FoodDeliver.Data;
using FoodDeliver.Models;
using System.Security.Claims;
using iText.IO.Font;
using iText.IO.Font.Constants;
using iText.Kernel.Colors;
using iText.Kernel.Font;
using iText.Layout.Properties;
using System.ComponentModel;

namespace FoodDeliver.Services;

public class ReportService : IReportService
{
    private readonly AppDbContext _context;

    public ReportService(AppDbContext context)
    {
        _context = context;
        // Set EPPlus license context
        ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.Commercial;
    }

    public async Task<byte[]> GenerateOrdersReportAsync(DateTime startDate, DateTime endDate, string format)
    {
        var orders = await _context.Orders
            .Include(o => o.User)
            .Include(o => o.Restaurant)
            .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.MenuItem)
            .Where(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();

        var data = orders.Select(o => new
        {
            OrderId = o.Id,
            CustomerName = o.User.Name,
            RestaurantName = o.Restaurant.Name,
            Total = o.Total,
            Status = o.Status,
            PaymentStatus = o.PaymentStatus,
            CreatedAt = o.CreatedAt,
            Items = string.Join(", ", o.OrderItems.Select(oi => $"{oi.MenuItem.Name} x{oi.Quantity}"))
        });

        return format.ToLower() switch
        {
            "csv" => GenerateCsv(data),
            "excel" => GenerateExcel(data, "Orders Report"),
            "pdf" => GeneratePdf(data, "Orders Report"),
            _ => throw new ArgumentException("Unsupported format")
        };
    }

    public async Task<byte[]> GenerateUsersReportAsync(DateTime startDate, DateTime endDate, string format)
    {
        var users = await _context.Users
            .Where(u => u.CreatedAt >= startDate && u.CreatedAt <= endDate)
            .OrderByDescending(u => u.CreatedAt)
            .ToListAsync();

        var data = users.Select(u => new
        {
            UserId = u.Id,
            Name = u.Name,
            Email = u.Email,
            Role = u.Role,
            Status = u.Status,
            CreatedAt = u.CreatedAt,
            LastLoginAt = u.LastLoginAt,
            OrderCount = u.Orders.Count,
            FeedbackCount = u.Feedbacks.Count
        });

        return format.ToLower() switch
        {
            "csv" => GenerateCsv(data),
            "excel" => GenerateExcel(data, "Users Report"),
            "pdf" => GeneratePdf(data, "Users Report"),
            _ => throw new ArgumentException("Unsupported format")
        };
    }

    public async Task<byte[]> GenerateRestaurantsReportAsync(DateTime startDate, DateTime endDate, string format)
    {
        var restaurants = await _context.Restaurants
            .Where(r => r.CreatedAt >= startDate && r.CreatedAt <= endDate)
            .OrderByDescending(r => r.CreatedAt)
            .ToListAsync();

        var data = restaurants.Select(r => new
        {
            RestaurantId = r.Id,
            Name = r.Name,
            Rating = r.Rating,
            DeliveryTime = r.DeliveryTime,
            DeliveryFee = r.DeliveryFee,
            IsActive = r.IsActive,
            CreatedAt = r.CreatedAt,
            MenuItemCount = r.MenuItems.Count,
            OrderCount = r.Orders.Count,
            FeedbackCount = r.Feedbacks.Count
        });

        return format.ToLower() switch
        {
            "csv" => GenerateCsv(data),
            "excel" => GenerateExcel(data, "Restaurants Report"),
            "pdf" => GeneratePdf(data, "Restaurants Report"),
            _ => throw new ArgumentException("Unsupported format")
        };
    }

    public async Task<byte[]> GenerateFeedbackReportAsync(DateTime startDate, DateTime endDate, string format)
    {
        var feedbacks = await _context.Feedbacks
            .Include(f => f.User)
            .Include(f => f.Restaurant)
            .Where(f => f.CreatedAt >= startDate && f.CreatedAt <= endDate)
            .OrderByDescending(f => f.CreatedAt)
            .ToListAsync();

        var data = feedbacks.Select(f => new
        {
            FeedbackId = f.Id,
            UserName = f.User.Name,
            RestaurantName = f.Restaurant.Name,
            Rating = f.Rating,
            Message = f.Message,
            Status = f.Status,
            Response = f.Response,
            CreatedAt = f.CreatedAt
        });

        return format.ToLower() switch
        {
            "csv" => GenerateCsv(data),
            "excel" => GenerateExcel(data, "Feedback Report"),
            "pdf" => GeneratePdf(data, "Feedback Report"),
            _ => throw new ArgumentException("Unsupported format")
        };
    }

    public async Task<byte[]> GenerateAnalyticsReportAsync(DateTime startDate, DateTime endDate, string format)
    {
        var analytics = new
        {
            TotalOrders = await _context.Orders
                .CountAsync(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate),
            TotalRevenue = await _context.Orders
                .Where(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate && o.Status != "cancelled")
                .SumAsync(o => o.Total),
            AverageOrderValue = await _context.Orders
                .Where(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate && o.Status != "cancelled")
                .AverageAsync(o => o.Total),
            TotalUsers = await _context.Users
                .CountAsync(u => u.CreatedAt >= startDate && u.CreatedAt <= endDate),
            TotalRestaurants = await _context.Restaurants
                .CountAsync(r => r.CreatedAt >= startDate && r.CreatedAt <= endDate),
            AverageRating = await _context.Feedbacks
                .Where(f => f.CreatedAt >= startDate && f.CreatedAt <= endDate && f.Rating.HasValue)
                .AverageAsync(f => f.Rating!.Value)
        };

        var data = new[] { analytics };

        return format.ToLower() switch
        {
            "csv" => GenerateCsv(data),
            "excel" => GenerateExcel(data, "Analytics Report"),
            "pdf" => GeneratePdf(data, "Analytics Report"),
            _ => throw new ArgumentException("Unsupported format")
        };
    }

    private byte[] GenerateCsv<T>(IEnumerable<T> data)
    {
        using var memoryStream = new MemoryStream();
        using var writer = new StreamWriter(memoryStream, Encoding.UTF8);
        using var csv = new CsvWriter(writer, CultureInfo.InvariantCulture);
        
        csv.WriteRecords(data);
        writer.Flush();
        
        return memoryStream.ToArray();
    }

    private byte[] GenerateExcel<T>(IEnumerable<T> data, string sheetName)
    {
        using var package = new ExcelPackage();
        var worksheet = package.Workbook.Worksheets.Add(sheetName);
        
        // Add headers
        var properties = typeof(T).GetProperties();
        for (int i = 0; i < properties.Length; i++)
        {
            worksheet.Cells[1, i + 1].Value = properties[i].Name;
            worksheet.Cells[1, i + 1].Style.Font.Bold = true;
        }

        // Add data
        var row = 2;
        foreach (var item in data)
        {
            for (int i = 0; i < properties.Length; i++)
            {
                worksheet.Cells[row, i + 1].Value = properties[i].GetValue(item)?.ToString();
            }
            row++;
        }

        // Auto-fit columns
        worksheet.Cells.AutoFitColumns();

        return package.GetAsByteArray();
    }

    private byte[] GeneratePdf<T>(IEnumerable<T> data, string title)
    {
        using var memoryStream = new MemoryStream();
        var writer = new PdfWriter(memoryStream);
        var pdf = new PdfDocument(writer);
        var document = new Document(pdf);

        // Create fonts
        var boldFont = PdfFontFactory.CreateFont(StandardFonts.HELVETICA_BOLD);
        var normalFont = PdfFontFactory.CreateFont(StandardFonts.HELVETICA);

        // Add title
        document.Add(new Paragraph(title)
            .SetFont(boldFont)
            .SetFontSize(20)
            .SetTextAlignment(TextAlignment.CENTER));

        // Create table
        var properties = typeof(T).GetProperties();
        var table = new Table(properties.Length, true);

        // Add headers
        foreach (var property in properties)
        {
            table.AddCell(new Cell()
                .Add(new Paragraph(property.Name)
                    .SetFont(boldFont))
                .SetBackgroundColor(new DeviceGray(0.9f))); // Fixed color
        }

        // Add data rows
        foreach (var item in data)
        {
            foreach (var property in properties)
            {
                var value = property.GetValue(item)?.ToString() ?? string.Empty;
                table.AddCell(new Cell()
                    .Add(new Paragraph(value) // Fixed parenthesis
                        .SetFont(normalFont)));
            }
        }

        document.Add(table);
        document.Close();

        return memoryStream.ToArray();
    }

    public Task<byte[]> GenerateReportAsync(DateTime startDate, DateTime endDate)
    {
        throw new NotImplementedException();
    }
} 