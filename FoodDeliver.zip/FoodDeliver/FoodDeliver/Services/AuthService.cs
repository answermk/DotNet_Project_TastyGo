using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using FoodDeliver.Data;
using FoodDeliver.Models;
using System.Security.Cryptography;

namespace FoodDeliver.Services;

public class AuthService : IAuthService
{
    private readonly AppDbContext _context;
    private readonly IConfiguration _configuration;
    private const string ADMIN_EMAIL = "admin.answer@gmail.com";
    private const string ADMIN_PASSWORD = "admin";

    public AuthService(AppDbContext context, IConfiguration configuration)
    {
        _context = context;
        _configuration = configuration;
    }

    public async Task<(User user, string token)> LoginAsync(string email, string password)
    {
        // Check for admin login first
        if (email == ADMIN_EMAIL && password == ADMIN_PASSWORD)
        {
            var adminUser = await _context.Users.FirstOrDefaultAsync(u => u.Email == ADMIN_EMAIL);
            if (adminUser == null)
            {
                adminUser = new User
                {
                    Name = "Admin",
                    Email = ADMIN_EMAIL,
                    PasswordHash = ADMIN_PASSWORD, // In production, this should be hashed
                    Role = "admin",
                    Status = "active",
                    CreatedAt = DateTime.UtcNow
                };
                _context.Users.Add(adminUser);
                await _context.SaveChangesAsync();
            }

            adminUser.LastLoginAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            var token = GenerateJwtToken(adminUser);
            return (adminUser, token);
        }

        // Regular user login
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        if (user == null)
        {
            throw new Exception("Invalid email or password");
        }

        // In a real application, you would verify the password hash here
        // For demo purposes, we'll skip password verification
        if (user.Status != "active")
        {
            throw new Exception("Account is not active");
        }

        user.LastLoginAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        var userToken = GenerateJwtToken(user);
        return (user, userToken);
    }

    public async Task<(User user, string token)> RegisterAsync(string name, string email, string password)
    {
        if (await _context.Users.AnyAsync(u => u.Email == email))
        {
            throw new Exception("Email is already registered");
        }

        // In a real application, you would hash the password here
        var user = new User
        {
            Name = name,
            Email = email,
            PasswordHash = password, // In production, this should be hashed
            Role = "customer",
            Status = "active",
            CreatedAt = DateTime.UtcNow
        };

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        var token = GenerateJwtToken(user);
        return (user, token);
    }

    public async Task<User?> GetUserByIdAsync(string id)
    {
        return await _context.Users.FindAsync(id);
    }

    public async Task<User?> GetUserByEmailAsync(string email)
    {
        return await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
    }

    public async Task<bool> UpdateUserStatusAsync(string userId, string status)
    {
        var user = await _context.Users.FindAsync(userId);
        if (user == null)
        {
            return false;
        }

        user.Status = status;
        await _context.SaveChangesAsync();
        return true;
    }

    public string GenerateJwtToken(User user)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"] ?? throw new InvalidOperationException("JWT Key not found")));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id),
            new Claim(ClaimTypes.Email, user.Email),
            new Claim(ClaimTypes.Name, user.Name),
            new Claim(ClaimTypes.Role, user.Role)
        };

        var token = new JwtSecurityToken(
            issuer: _configuration["Jwt:Issuer"],
            audience: _configuration["Jwt:Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(Convert.ToDouble(_configuration["Jwt:ExpiryInMinutes"])),
            signingCredentials: credentials
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    public async Task<bool> ForgotPasswordAsync(string email)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        if (user == null)
        {
            // Return true even if user doesn't exist to prevent email enumeration
            return true;
        }

        // Generate a random token
        var token = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));
        user.PasswordResetToken = token;
        user.PasswordResetTokenExpiry = DateTime.UtcNow.AddHours(1); // Token valid for 1 hour
        await _context.SaveChangesAsync();

        // In a real application, you would send an email with the reset token
        // For demo purposes, we'll just return true
        return true;
    }

    public async Task<bool> ResetPasswordAsync(string email, string token, string newPassword)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => 
            u.Email == email && 
            u.PasswordResetToken == token && 
            u.PasswordResetTokenExpiry > DateTime.UtcNow);

        if (user == null)
        {
            return false;
        }

        // In a real application, you would hash the password here
        user.PasswordHash = newPassword;
        user.PasswordResetToken = null;
        user.PasswordResetTokenExpiry = null;
        await _context.SaveChangesAsync();

        return true;
    }

    public async Task<bool> ValidateAdminCredentialsAsync(string email, string password)
    {
        if (email == ADMIN_EMAIL && password == ADMIN_PASSWORD)
        {
            // Check if admin user exists, if not create it
            var adminUser = await _context.Users.FirstOrDefaultAsync(u => u.Email == ADMIN_EMAIL);
            if (adminUser == null)
            {
                adminUser = new User
                {
                    Name = "Admin",
                    Email = ADMIN_EMAIL,
                    PasswordHash = ADMIN_PASSWORD, // In production, this should be hashed
                    Role = "admin",
                    Status = "active",
                    CreatedAt = DateTime.UtcNow
                };
                _context.Users.Add(adminUser);
                await _context.SaveChangesAsync();
            }
            return true;
        }
        return false;
    }

    public async Task<bool> ChangePasswordAsync(string userId, string currentPassword, string newPassword)
    {
        var user = await _context.Users.FindAsync(userId);
        if (user == null)
        {
            return false;
        }

        // For admin user, check against hardcoded password
        if (user.Email == ADMIN_EMAIL)
        {
            if (currentPassword != ADMIN_PASSWORD)
            {
                return false;
            }
            user.PasswordHash = newPassword; // In production, this should be hashed
            await _context.SaveChangesAsync();
            return true;
        }

        // For regular users, verify current password
        // In a real application, you would verify the password hash here
        if (user.PasswordHash != currentPassword)
        {
            return false;
        }

        // Update password
        // In a real application, you would hash the new password here
        user.PasswordHash = newPassword;
        await _context.SaveChangesAsync();
        return true;
    }
} 