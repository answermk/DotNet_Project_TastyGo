using System.Threading.Tasks;
using FoodDeliver.Services.Interfaces;

namespace FoodDeliver.Services
{
 public class FileService : IFileService
 {
  public async Task<string> UploadFileAsync(byte[] fileData, string fileName, string fileType) { throw new System.NotImplementedException(); }
 }

} 