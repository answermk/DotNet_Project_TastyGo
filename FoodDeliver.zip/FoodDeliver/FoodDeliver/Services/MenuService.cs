using Microsoft.EntityFrameworkCore;
using FoodDeliver.Data;
using FoodDeliver.Models;

namespace FoodDeliver.Services;

public class MenuService : IMenuService
{
    private readonly AppDbContext _context;

    public MenuService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<MenuItem>> GetAllMenuItemsAsync()
    {
        return await _context.MenuItems
            .Where(m => m.IsAvailable)
            .OrderBy(m => m.RestaurantId)
            .ThenBy(m => m.Category)
            .ToListAsync();
    }

    public async Task<MenuItem?> GetMenuItemByIdAsync(string id)
    {
        return await _context.MenuItems
            .Include(m => m.Restaurant)
            .FirstOrDefaultAsync(m => m.Id == id);
    }

    public async Task<IEnumerable<MenuItem>> GetMenuItemsByRestaurantAsync(string restaurantId)
    {
        return await _context.MenuItems
            .Where(m => m.RestaurantId == restaurantId && m.IsAvailable)
            .OrderBy(m => m.Category)
            .ToListAsync();
    }

    public async Task<MenuItem> CreateMenuItemAsync(MenuItem menuItem)
    {
        menuItem.CreatedAt = DateTime.UtcNow;
        _context.MenuItems.Add(menuItem);
        await _context.SaveChangesAsync();
        return menuItem;
    }

    public async Task<MenuItem> UpdateMenuItemAsync(string id, MenuItem menuItem)
    {
        var existingMenuItem = await _context.MenuItems.FindAsync(id);
        if (existingMenuItem == null)
        {
            throw new Exception("Menu item not found");
        }

        existingMenuItem.Name = menuItem.Name;
        existingMenuItem.Description = menuItem.Description;
        existingMenuItem.Image = menuItem.Image;
        existingMenuItem.Price = menuItem.Price;
        existingMenuItem.Category = menuItem.Category;
        existingMenuItem.DietaryInfo = menuItem.DietaryInfo;
        existingMenuItem.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        return existingMenuItem;
    }

    public async Task<bool> DeleteMenuItemAsync(string id)
    {
        var menuItem = await _context.MenuItems.FindAsync(id);
        if (menuItem == null)
        {
            return false;
        }

        _context.MenuItems.Remove(menuItem);
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<bool> UpdateMenuItemAvailabilityAsync(string id, bool isAvailable)
    {
        var menuItem = await _context.MenuItems.FindAsync(id);
        if (menuItem == null)
        {
            return false;
        }

        menuItem.IsAvailable = isAvailable;
        menuItem.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<IEnumerable<MenuItem>> GetMenuItemsByCategoryAsync(string restaurantId, string category)
    {
        return await _context.MenuItems
            .Where(m => m.RestaurantId == restaurantId && m.Category == category && m.IsAvailable)
            .OrderBy(m => m.Name)
            .ToListAsync();
    }

    public async Task<IEnumerable<string>> GetMenuCategoriesAsync(string restaurantId)
    {
        return await _context.MenuItems
            .Where(m => m.RestaurantId == restaurantId && m.IsAvailable)
            .Select(m => m.Category!)
            .Distinct()
            .OrderBy(c => c)
            .ToListAsync();
    }
} 