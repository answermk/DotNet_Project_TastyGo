using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using FoodDeliver.Services.Interfaces;

namespace FoodDeliver.Services
{
 public class AnalyticsHub : Hub, IAnalyticsHub
 {
  public async Task SendAnalyticsUpdateAsync(object data) { throw new System.NotImplementedException(); }
 }

} 