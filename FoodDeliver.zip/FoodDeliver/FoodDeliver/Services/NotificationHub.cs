using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using FoodDeliver.Services.Interfaces;

namespace FoodDeliver.Services
{
 public class NotificationHub : Hub, INotificationHub
 {
  public async Task SendNotificationAsync(object notification) { throw new System.NotImplementedException(); }
 }

} 