using System.Threading.Tasks;
using FoodDeliver.Services.Interfaces;

namespace FoodDeliver.Services
{
 public class AnalyticsService : IAnalyticsService
 {
  public async Task<object> GetAnalyticsAsync() { throw new System.NotImplementedException(); }
 }

} 