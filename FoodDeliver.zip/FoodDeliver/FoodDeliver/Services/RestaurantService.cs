using Microsoft.EntityFrameworkCore;
using FoodDeliver.Data;
using FoodDeliver.Models;

namespace FoodDeliver.Services;

public class RestaurantService : IRestaurantService
{
    private readonly AppDbContext _context;

    public RestaurantService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Restaurant>> GetAllRestaurantsAsync()
    {
        return await _context.Restaurants
            .Where(r => r.IsActive)
            .OrderByDescending(r => r.Rating)
            .ToListAsync();
    }

    public async Task<Restaurant?> GetRestaurantByIdAsync(string id)
    {
        return await _context.Restaurants
            .Include(r => r.MenuItems)
            .FirstOrDefaultAsync(r => r.Id == id);
    }

    public async Task<Restaurant> CreateRestaurantAsync(Restaurant restaurant)
    {
        restaurant.CreatedAt = DateTime.UtcNow;
        _context.Restaurants.Add(restaurant);
        await _context.SaveChangesAsync();
        return restaurant;
    }

    public async Task<Restaurant> UpdateRestaurantAsync(string id, Restaurant restaurant)
    {
        var existingRestaurant = await _context.Restaurants.FindAsync(id);
        if (existingRestaurant == null)
        {
            throw new Exception("Restaurant not found");
        }

        existingRestaurant.Name = restaurant.Name;
        existingRestaurant.Description = restaurant.Description;
        existingRestaurant.Image = restaurant.Image;
        existingRestaurant.DeliveryTime = restaurant.DeliveryTime;
        existingRestaurant.DeliveryFee = restaurant.DeliveryFee;
        existingRestaurant.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        return existingRestaurant;
    }

    public async Task<bool> DeleteRestaurantAsync(string id)
    {
        var restaurant = await _context.Restaurants.FindAsync(id);
        if (restaurant == null)
        {
            return false;
        }

        _context.Restaurants.Remove(restaurant);
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<bool> UpdateRestaurantStatusAsync(string id, bool isActive)
    {
        var restaurant = await _context.Restaurants.FindAsync(id);
        if (restaurant == null)
        {
            return false;
        }

        restaurant.IsActive = isActive;
        restaurant.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<IEnumerable<MenuItem>> GetRestaurantMenuItemsAsync(string restaurantId)
    {
        return await _context.MenuItems
            .Where(m => m.RestaurantId == restaurantId && m.IsAvailable)
            .OrderBy(m => m.Category)
            .ToListAsync();
    }

    public async Task<IEnumerable<Order>> GetRestaurantOrdersAsync(string restaurantId)
    {
        return await _context.Orders
            .Where(o => o.RestaurantId == restaurantId)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();
    }

    public async Task<IEnumerable<Feedback>> GetRestaurantFeedbacksAsync(string restaurantId)
    {
        return await _context.Feedbacks
            .Where(f => f.RestaurantId == restaurantId)
            .OrderByDescending(f => f.CreatedAt)
            .ToListAsync();
    }

    public async Task<double> UpdateRestaurantRatingAsync(string restaurantId)
    {
        var averageRating = await _context.Feedbacks
            .Where(f => f.RestaurantId == restaurantId && f.Rating.HasValue)
            .AverageAsync(f => f.Rating!.Value);

        var restaurant = await _context.Restaurants.FindAsync(restaurantId);
        if (restaurant != null)
        {
            restaurant.Rating = averageRating;
            restaurant.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();
        }

        return averageRating;
    }

    public async Task<int> GetTotalRestaurantsCountAsync()
    {
        return await _context.Restaurants.CountAsync();
    }

    public async Task<int> GetActiveRestaurantsCountAsync()
    {
        return await _context.Restaurants.CountAsync(r => r.IsActive);
    }

    public async Task<IEnumerable<object>> GetTopPerformingRestaurantsAsync()
    {
        var topRestaurants = await _context.Restaurants
            .Where(r => r.IsActive)
            .OrderByDescending(r => r.Rating)
            .Select(r => new { RestaurantId = r.Id, Name = r.Name, Rating = r.Rating })
            .ToListAsync();
        return topRestaurants;
    }

    public async Task<double> GetAverageRatingAsync()
    {
        return await _context.Restaurants
            .Where(r => r.IsActive && r.Rating.HasValue)
            .AverageAsync(r => r.Rating!.Value);
    }

    public async Task<object> GetRestaurantPerformanceAsync(DateTime startDate, DateTime endDate)
    {
        var performance = await _context.Restaurants
            .Where(r => r.IsActive)
            .Select(r => new
            {
                RestaurantId = r.Id,
                Name = r.Name,
                TotalOrders = r.Orders.Count(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate),
                TotalRevenue = r.Orders
                    .Where(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate && o.Status != "cancelled")
                    .Sum(o => o.Total),
                AverageRating = r.Rating,
                CompletionRate = r.Orders
                    .Where(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate)
                    .Count(o => o.Status == "delivered") * 100.0 / 
                    r.Orders.Count(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate)
            })
            .OrderByDescending(p => p.TotalRevenue)
            .ToListAsync();

        return performance;
    }
} 