using Microsoft.EntityFrameworkCore;
using FoodDeliver.Data;
using FoodDeliver.Models;

namespace FoodDeliver.Services;

public class FeedbackService : IFeedbackService
{
    private readonly AppDbContext _context;
    private readonly IRestaurantService _restaurantService;

    public FeedbackService(AppDbContext context, IRestaurantService restaurantService)
    {
        _context = context;
        _restaurantService = restaurantService;
    }

    public async Task<IEnumerable<Feedback>> GetAllFeedbacksAsync()
    {
        return await _context.Feedbacks
            .Include(f => f.User)
            .Include(f => f.Restaurant)
            .Include(f => f.Order)
            .OrderByDescending(f => f.CreatedAt)
            .ToListAsync();
    }

    public async Task<Feedback?> GetFeedbackByIdAsync(string id)
    {
        return await _context.Feedbacks
            .Include(f => f.User)
            .Include(f => f.Restaurant)
            .Include(f => f.Order)
            .FirstOrDefaultAsync(f => f.Id == id);
    }

    public async Task<IEnumerable<Feedback>> GetFeedbacksByUserAsync(string userId)
    {
        return await _context.Feedbacks
            .Include(f => f.Restaurant)
            .Include(f => f.Order)
            .Where(f => f.UserId == userId)
            .OrderByDescending(f => f.CreatedAt)
            .ToListAsync();
    }

    public async Task<IEnumerable<Feedback>> GetFeedbacksByRestaurantAsync(string restaurantId)
    {
        return await _context.Feedbacks
            .Include(f => f.User)
            .Include(f => f.Order)
            .Where(f => f.RestaurantId == restaurantId)
            .OrderByDescending(f => f.CreatedAt)
            .ToListAsync();
    }

    public async Task<Feedback> CreateFeedbackAsync(Feedback feedback)
    {
        feedback.CreatedAt = DateTime.UtcNow;
        _context.Feedbacks.Add(feedback);
        await _context.SaveChangesAsync();

        // Update restaurant rating if rating is provided
        if (feedback.Rating.HasValue)
        {
            await _restaurantService.UpdateRestaurantRatingAsync(feedback.RestaurantId);
        }

        return await GetFeedbackByIdAsync(feedback.Id) ?? throw new Exception("Failed to retrieve created feedback");
    }

    public async Task<Feedback> UpdateFeedbackStatusAsync(string id, string status)
    {
        var feedback = await _context.Feedbacks.FindAsync(id);
        if (feedback == null)
        {
            throw new Exception("Feedback not found");
        }

        feedback.Status = status;
        feedback.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return await GetFeedbackByIdAsync(id) ?? throw new Exception("Failed to retrieve updated feedback");
    }

    public async Task<Feedback> AddFeedbackResponseAsync(string id, string response)
    {
        var feedback = await _context.Feedbacks.FindAsync(id);
        if (feedback == null)
        {
            throw new Exception("Feedback not found");
        }

        feedback.Response = response;
        feedback.Status = "resolved";
        feedback.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return await GetFeedbackByIdAsync(id) ?? throw new Exception("Failed to retrieve updated feedback");
    }

    public async Task<IEnumerable<Feedback>> GetFeedbacksByStatusAsync(string status)
    {
        return await _context.Feedbacks
            .Include(f => f.User)
            .Include(f => f.Restaurant)
            .Include(f => f.Order)
            .Where(f => f.Status == status)
            .OrderByDescending(f => f.CreatedAt)
            .ToListAsync();
    }

    public async Task<double> GetAverageRatingAsync(string restaurantId)
    {
        return await _context.Feedbacks
            .Where(f => f.RestaurantId == restaurantId && f.Rating.HasValue)
            .AverageAsync(f => f.Rating!.Value);
    }

    public async Task<int> GetTotalFeedbacksCountAsync()
    {
        return await _context.Feedbacks.CountAsync();
    }

    public async Task<double> GetAverageRatingAsync()
    {
        return await _context.Feedbacks
            .Where(f => f.Rating.HasValue)
            .AverageAsync(f => f.Rating!.Value);
    }

    public async Task<double> GetSatisfactionRateAsync()
    {
        var totalFeedbacks = await _context.Feedbacks.CountAsync(f => f.Rating.HasValue);
        if (totalFeedbacks == 0) return 0;
        var satisfiedFeedbacks = await _context.Feedbacks.CountAsync(f => f.Rating.HasValue && f.Rating.Value >= 4);
        return (double)satisfiedFeedbacks / totalFeedbacks;
    }

    public async Task<object> GetFeedbackStatusBreakdownAsync()
    {
        var breakdown = await _context.Feedbacks
            .GroupBy(f => f.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToListAsync();
        return breakdown;
    }

    public async Task<IEnumerable<Feedback>> GetRecentFeedbacksAsync(int count)
    {
        return await _context.Feedbacks
            .OrderByDescending(f => f.CreatedAt)
            .Take(count)
            .ToListAsync();
    }

    public async Task<bool> DeleteFeedbackAsync(string id)
    {
        var feedback = await _context.Feedbacks.FindAsync(id);
        if (feedback == null)
        {
            return false;
        }

        _context.Feedbacks.Remove(feedback);
        await _context.SaveChangesAsync();

        // Update restaurant rating after deletion
        if (feedback.Rating.HasValue)
        {
            await _restaurantService.UpdateRestaurantRatingAsync(feedback.RestaurantId);
        }

        return true;
    }
} 