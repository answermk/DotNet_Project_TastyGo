using System.Threading.Tasks;
using FoodDeliver.Services.Interfaces;

namespace FoodDeliver.Services
{
 public class BackupService : IBackupService
 {
  public async Task<bool> CreateBackupAsync() { throw new System.NotImplementedException(); }
 }

} 