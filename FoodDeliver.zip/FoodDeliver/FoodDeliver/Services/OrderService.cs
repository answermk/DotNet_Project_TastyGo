using Microsoft.EntityFrameworkCore;
using FoodDeliver.Data;
using FoodDeliver.Models;

namespace FoodDeliver.Services;

public class OrderService : IOrderService
{
    private readonly AppDbContext _context;

    public OrderService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Order>> GetAllOrdersAsync()
    {
        return await _context.Orders
            .Include(o => o.User)
            .Include(o => o.Restaurant)
            .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.MenuItem)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();
    }

    public async Task<Order?> GetOrderByIdAsync(string id)
    {
        return await _context.Orders
            .Include(o => o.User)
            .Include(o => o.Restaurant)
            .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.MenuItem)
            .FirstOrDefaultAsync(o => o.Id == id);
    }

    public async Task<IEnumerable<Order>> GetOrdersByUserAsync(string userId)
    {
        return await _context.Orders
            .Include(o => o.Restaurant)
            .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.MenuItem)
            .Where(o => o.UserId == userId)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();
    }

    public async Task<IEnumerable<Order>> GetOrdersByRestaurantAsync(string restaurantId)
    {
        return await _context.Orders
            .Include(o => o.User)
            .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.MenuItem)
            .Where(o => o.RestaurantId == restaurantId)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();
    }

    public async Task<Order> CreateOrderAsync(Order order, IEnumerable<OrderItem> orderItems)
    {
        using var transaction = await _context.Database.BeginTransactionAsync();
        try
        {
            // Calculate total
            decimal total = 0;
            foreach (var item in orderItems)
            {
                var menuItem = await _context.MenuItems.FindAsync(item.MenuItemId);
                if (menuItem == null)
                {
                    throw new Exception($"Menu item {item.MenuItemId} not found");
                }
                if (!menuItem.IsAvailable)
                {
                    throw new Exception($"Menu item {menuItem.Name} is not available");
                }
                item.Price = menuItem.Price;
                total += item.Price * item.Quantity;
            }

            order.Total = total;
            order.CreatedAt = DateTime.UtcNow;

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            foreach (var item in orderItems)
            {
                item.OrderId = order.Id;
                _context.OrderItems.Add(item);
            }
            await _context.SaveChangesAsync();

            await transaction.CommitAsync();
            return await GetOrderByIdAsync(order.Id) ?? throw new Exception("Failed to retrieve created order");
        }
        catch
        {
            await transaction.RollbackAsync();
            throw;
        }
    }

    public async Task<Order> UpdateOrderStatusAsync(string id, string status)
    {
        var order = await _context.Orders.FindAsync(id);
        if (order == null)
        {
            throw new Exception("Order not found");
        }

        order.Status = status;
        order.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return await GetOrderByIdAsync(id) ?? throw new Exception("Failed to retrieve updated order");
    }

    public async Task<Order> UpdatePaymentStatusAsync(string id, string status)
    {
        var order = await _context.Orders.FindAsync(id);
        if (order == null)
        {
            throw new Exception("Order not found");
        }

        order.PaymentStatus = status;
        order.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return await GetOrderByIdAsync(id) ?? throw new Exception("Failed to retrieve updated order");
    }

    public async Task<bool> CancelOrderAsync(string id)
    {
        var order = await _context.Orders.FindAsync(id);
        if (order == null)
        {
            return false;
        }

        // Only allow cancellation of pending orders
        if (order.Status != "pending")
        {
            return false;
        }

        order.Status = "cancelled";
        order.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<IEnumerable<Order>> GetOrdersByStatusAsync(string status)
    {
        return await _context.Orders
            .Include(o => o.User)
            .Include(o => o.Restaurant)
            .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.MenuItem)
            .Where(o => o.Status == status)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();
    }

    public async Task<decimal> GetTotalRevenueAsync(DateTime startDate, DateTime endDate)
    {
        return await _context.Orders
            .Where(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate && o.Status != "cancelled")
            .SumAsync(o => o.Total);
    }

    public async Task<int> GetOrderCountAsync(DateTime startDate, DateTime endDate)
    {
        return await _context.Orders
            .CountAsync(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate && o.Status != "cancelled");
    }

    public async Task<int> GetTotalOrdersCountAsync()
    {
        return await _context.Orders.CountAsync(o => o.Status != "cancelled");
    }

    public async Task<decimal> GetTotalRevenueAsync()
    {
        return await _context.Orders
            .Where(o => o.Status != "cancelled")
            .SumAsync(o => o.Total);
    }

    public async Task<int> GetOrdersByStatusCountAsync(string status)
    {
        return await _context.Orders.CountAsync(o => o.Status == status);
    }

    public async Task<object> GetOrdersStatusBreakdownAsync()
    {
        var breakdown = await _context.Orders
            .GroupBy(o => o.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToListAsync();
        return breakdown;
    }

    public async Task<decimal> GetMonthlyRevenueAsync()
    {
        var startDate = DateTime.UtcNow.AddMonths(-1);
        var endDate = DateTime.UtcNow;
        return await GetTotalRevenueAsync(startDate, endDate);
    }

    public async Task<double> GetOrderCompletionRateAsync()
    {
        var totalOrders = await _context.Orders.CountAsync(o => o.Status != "cancelled");
        if (totalOrders == 0) return 0;
        var completedOrders = await _context.Orders.CountAsync(o => o.Status == "completed");
        return (double)completedOrders / totalOrders;
    }

    public async Task<IEnumerable<object>> GetPopularRestaurantsAsync(DateTime startDate, DateTime endDate)
    {
        var popularRestaurants = await _context.Orders
            .Where(o => o.CreatedAt >= startDate && o.CreatedAt <= endDate && o.Status != "cancelled")
            .GroupBy(o => o.RestaurantId)
            .Select(g => new { RestaurantId = g.Key, OrderCount = g.Count() })
            .OrderByDescending(r => r.OrderCount)
            .ToListAsync();
        return popularRestaurants;
    }
} 