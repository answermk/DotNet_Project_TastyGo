using System.Threading.Tasks;

namespace FoodDeliver.Services.Interfaces
{
    public interface IBackupService
    {
        Task<bool> CreateBackupAsync();
    }
} 