using FoodDeliver.Models;

namespace FoodDeliver.Services;

public interface IRestaurantService
{
    Task<IEnumerable<Restaurant>> GetAllRestaurantsAsync();
    Task<Restaurant?> GetRestaurantByIdAsync(string id);
    Task<Restaurant> CreateRestaurantAsync(Restaurant restaurant);
    Task<Restaurant> UpdateRestaurantAsync(string id, Restaurant restaurant);
    Task<bool> DeleteRestaurantAsync(string id);
    Task<bool> UpdateRestaurantStatusAsync(string id, bool isActive);
    Task<IEnumerable<MenuItem>> GetRestaurantMenuItemsAsync(string restaurantId);
    Task<IEnumerable<Order>> GetRestaurantOrdersAsync(string restaurantId);
    Task<IEnumerable<Feedback>> GetRestaurantFeedbacksAsync(string restaurantId);
    Task<double> UpdateRestaurantRatingAsync(string restaurantId);
    Task<int> GetTotalRestaurantsCountAsync();
    Task<int> GetActiveRestaurantsCountAsync();
    Task<IEnumerable<object>> GetTopPerformingRestaurantsAsync();
    Task<double> GetAverageRatingAsync();
    Task<object> GetRestaurantPerformanceAsync(DateTime startDate, DateTime endDate);
} 