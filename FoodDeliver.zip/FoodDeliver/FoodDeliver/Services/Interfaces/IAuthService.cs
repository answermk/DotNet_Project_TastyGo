using FoodDeliver.Models;

namespace FoodDeliver.Services;

public interface IAuthService
{
    Task<(User user, string token)> LoginAsync(string email, string password);
    Task<(User user, string token)> RegisterAsync(string name, string email, string password);
    Task<User?> GetUserByIdAsync(string id);
    Task<User?> GetUserByEmailAsync(string email);
    Task<bool> UpdateUserStatusAsync(string userId, string status);
    string GenerateJwtToken(User user);
    Task<bool> ForgotPasswordAsync(string email);
    Task<bool> ResetPasswordAsync(string email, string token, string newPassword);
    Task<bool> ValidateAdminCredentialsAsync(string email, string password);
    Task<bool> ChangePasswordAsync(string userId, string currentPassword, string newPassword);
} 