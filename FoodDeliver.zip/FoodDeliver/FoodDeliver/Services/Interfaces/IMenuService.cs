using FoodDeliver.Models;

namespace FoodDeliver.Services;

public interface IMenuService
{
    Task<IEnumerable<MenuItem>> GetAllMenuItemsAsync();
    Task<MenuItem?> GetMenuItemByIdAsync(string id);
    Task<IEnumerable<MenuItem>> GetMenuItemsByRestaurantAsync(string restaurantId);
    Task<MenuItem> CreateMenuItemAsync(MenuItem menuItem);
    Task<MenuItem> UpdateMenuItemAsync(string id, MenuItem menuItem);
    Task<bool> DeleteMenuItemAsync(string id);
    Task<bool> UpdateMenuItemAvailabilityAsync(string id, bool isAvailable);
    Task<IEnumerable<MenuItem>> GetMenuItemsByCategoryAsync(string restaurantId, string category);
    Task<IEnumerable<string>> GetMenuCategoriesAsync(string restaurantId);
} 