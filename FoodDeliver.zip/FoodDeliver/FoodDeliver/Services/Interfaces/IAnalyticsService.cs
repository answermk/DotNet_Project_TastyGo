using System.Threading.Tasks;

namespace FoodDeliver.Services.Interfaces
{
    public interface IAnalyticsService
    {
        Task<object> GetAnalyticsAsync();
    }
} 