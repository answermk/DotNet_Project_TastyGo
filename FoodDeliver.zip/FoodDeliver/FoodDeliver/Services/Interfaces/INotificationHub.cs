using System.Threading.Tasks;

namespace FoodDeliver.Services.Interfaces
{
    public interface INotificationHub
    {
        Task SendNotificationAsync(object notification);
    }
} 