using System.Threading.Tasks;

namespace FoodDeliver.Services.Interfaces
{
    public interface IFileService
    {
        Task<string> UploadFileAsync(byte[] fileData, string fileName, string fileType);
    }
} 