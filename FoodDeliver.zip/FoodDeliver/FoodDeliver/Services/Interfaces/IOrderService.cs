using FoodDeliver.Models;

namespace FoodDeliver.Services;

public interface IOrderService
{
    Task<IEnumerable<Order>> GetAllOrdersAsync();
    Task<Order?> GetOrderByIdAsync(string id);
    Task<IEnumerable<Order>> GetOrdersByUserAsync(string userId);
    Task<IEnumerable<Order>> GetOrdersByRestaurantAsync(string restaurantId);
    Task<Order> CreateOrderAsync(Order order, IEnumerable<OrderItem> orderItems);
    Task<Order> UpdateOrderStatusAsync(string id, string status);
    Task<Order> UpdatePaymentStatusAsync(string id, string status);
    Task<bool> CancelOrderAsync(string id);
    Task<IEnumerable<Order>> GetOrdersByStatusAsync(string status);
    Task<decimal> GetTotalRevenueAsync(DateTime startDate, DateTime endDate);
    Task<int> GetOrderCountAsync(DateTime startDate, DateTime endDate);
    Task<int> GetTotalOrdersCountAsync();
    Task<decimal> GetTotalRevenueAsync();
    Task<int> GetOrdersByStatusCountAsync(string status);
    Task<object> GetOrdersStatusBreakdownAsync();
    Task<decimal> GetMonthlyRevenueAsync();
    Task<double> GetOrderCompletionRateAsync();
    Task<IEnumerable<object>> GetPopularRestaurantsAsync(DateTime startDate, DateTime endDate);
} 