using FoodDeliver.Models;

namespace FoodDeliver.Services;

public interface IReportService
{
    Task<byte[]> GenerateOrdersReportAsync(DateTime startDate, DateTime endDate, string format);
    Task<byte[]> GenerateUsersReportAsync(DateTime startDate, DateTime endDate, string format);
    Task<byte[]> GenerateRestaurantsReportAsync(DateTime startDate, DateTime endDate, string format);
    Task<byte[]> GenerateFeedbackReportAsync(DateTime startDate, DateTime endDate, string format);
    Task<byte[]> GenerateAnalyticsReportAsync(DateTime startDate, DateTime endDate, string format);
    Task<byte[]> GenerateReportAsync(DateTime startDate, DateTime endDate);
} 