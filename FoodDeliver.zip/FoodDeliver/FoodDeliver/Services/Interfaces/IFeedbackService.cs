using FoodDeliver.Models;

namespace FoodDeliver.Services;

public interface IFeedbackService
{
    Task<IEnumerable<Feedback>> GetAllFeedbacksAsync();
    Task<Feedback?> GetFeedbackByIdAsync(string id);
    Task<IEnumerable<Feedback>> GetFeedbacksByUserAsync(string userId);
    Task<IEnumerable<Feedback>> GetFeedbacksByRestaurantAsync(string restaurantId);
    Task<Feedback> CreateFeedbackAsync(Feedback feedback);
    Task<Feedback> UpdateFeedbackStatusAsync(string id, string status);
    Task<Feedback> AddFeedbackResponseAsync(string id, string response);
    Task<IEnumerable<Feedback>> GetFeedbacksByStatusAsync(string status);
    Task<double> GetAverageRatingAsync(string restaurantId);
    Task<int> GetTotalFeedbacksCountAsync();
    Task<double> GetAverageRatingAsync();
    Task<double> GetSatisfactionRateAsync();
    Task<object> GetFeedbackStatusBreakdownAsync();
    Task<IEnumerable<Feedback>> GetRecentFeedbacksAsync(int count);
    Task<bool> DeleteFeedbackAsync(string id);
} 