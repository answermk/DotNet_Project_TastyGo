using System.Threading.Tasks;

namespace FoodDeliver.Services.Interfaces
{
    public interface IAnalyticsHub
    {
        Task SendAnalyticsUpdateAsync(object data);
    }
} 