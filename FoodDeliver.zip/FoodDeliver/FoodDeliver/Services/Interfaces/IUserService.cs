using FoodDeliver.Models;

namespace FoodDeliver.Services;

public interface IUserService
{
    Task<IEnumerable<User>> GetAllUsersAsync();
    Task<User?> GetUserByIdAsync(string id);
    Task<User?> GetUserByEmailAsync(string email);
    Task<User> CreateUserAsync(User user);
    Task<User> UpdateUserAsync(string id, User user);
    Task<bool> DeleteUserAsync(string id);
    Task<bool> UpdateUserStatusAsync(string id, string status);
    Task<IEnumerable<Order>> GetUserOrdersAsync(string userId);
    Task<IEnumerable<Feedback>> GetUserFeedbacksAsync(string userId);
    Task<int> GetTotalUsersCountAsync();
    Task<int> GetActiveUsersCountAsync();
    Task<int> GetNewUsersCountAsync(DateTime startDate);
} 