using System.ComponentModel.DataAnnotations;

namespace FoodDeliver.Models.DTOs;

public class CreateOrderItemRequest
{
    [Required]
    public string MenuItemId { get; set; } = string.Empty;
    
    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "Quantity must be at least 1")]
    public int Quantity { get; set; }
}

public class CreateOrderRequest
{
    [Required]
    public string RestaurantId { get; set; } = string.Empty;
    
    [Required]
    [MinLength(5, ErrorMessage = "Delivery address must be at least 5 characters long")]
    public string DeliveryAddress { get; set; } = string.Empty;
    
    [Required]
    [RegularExpression("^(momo-pay|cash)$", ErrorMessage = "Payment method must be either 'momo-pay' or 'cash'")]
    public string PaymentMethod { get; set; } = string.Empty;
    
    [Required]
    [MinLength(1, ErrorMessage = "Order must contain at least one item")]
    public IEnumerable<CreateOrderItemRequest> OrderItems { get; set; } = new List<CreateOrderItemRequest>();
}

public class UpdateOrderStatusRequest
{
    [Required]
    [RegularExpression("^(pending|confirmed|preparing|out-for-delivery|delivered|cancelled)$", 
        ErrorMessage = "Invalid order status")]
    public string Status { get; set; } = string.Empty;
}

public class UpdatePaymentStatusRequest
{
    [Required]
    [RegularExpression("^(pending|completed|failed)$", ErrorMessage = "Invalid payment status")]
    public string Status { get; set; } = string.Empty;
}

public class OrderResponse
{
    public string Id { get; set; } = string.Empty;
    public string UserId { get; set; } = string.Empty;
    public string RestaurantId { get; set; } = string.Empty;
    public string RestaurantName { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public decimal Total { get; set; }
    public string DeliveryAddress { get; set; } = string.Empty;
    public string PaymentMethod { get; set; } = string.Empty;
    public string PaymentStatus { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public IEnumerable<OrderItemResponse> Items { get; set; } = new List<OrderItemResponse>();
}

public class OrderItemResponse
{
    public string Id { get; set; } = string.Empty;
    public string MenuItemId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public int Quantity { get; set; }
    public string? SpecialInstructions { get; set; }
} 