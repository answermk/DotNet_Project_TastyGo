using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FoodDeliver.Models;

public class Order
{
    [Key]
    public string Id { get; set; } = Guid.NewGuid().ToString();
    
    [Required]
    public string UserId { get; set; } = string.Empty;
    
    [Required]
    public string RestaurantId { get; set; } = string.Empty;
    
    [Required]
    public string Status { get; set; } = "pending"; // pending, confirmed, preparing, out-for-delivery, delivered, cancelled
    
    [Required]
    [Column(TypeName = "decimal(18,2)")]
    public decimal Total { get; set; }
    
    [Required]
    public string DeliveryAddress { get; set; } = string.Empty;
    
    [Required]
    public string PaymentMethod { get; set; } = string.Empty; // "momo-pay" or "cash"
    
    [Required]
    public string PaymentStatus { get; set; } = "pending"; // pending, completed, failed
    
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    
    public DateTime? UpdatedAt { get; set; }
    
    // Navigation properties
    [ForeignKey("UserId")]
    public virtual User User { get; set; } = null!;
    
    [ForeignKey("RestaurantId")]
    public virtual Restaurant Restaurant { get; set; } = null!;
    
    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
} 