using System.ComponentModel.DataAnnotations;

namespace FoodDeliver.Models;

public class Restaurant
{
    [Key]
    public string Id { get; set; } = Guid.NewGuid().ToString();
    
    [Required]
    [StringLength(100)]
    public string Name { get; set; } = string.Empty;
    
    [Required]
    public string Description { get; set; } = string.Empty;
    
    [Required]
    public string Image { get; set; } = string.Empty;
    
    public double? Rating { get; set; }
    
    [Required]
    public string DeliveryTime { get; set; } = string.Empty; // e.g., "25-35 min"
    
    public decimal DeliveryFee { get; set; }
    
    public bool IsActive { get; set; } = true;
    
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    
    public DateTime? UpdatedAt { get; set; }
    
    // Navigation properties
    public virtual ICollection<MenuItem> MenuItems { get; set; } = new List<MenuItem>();
    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
    public virtual ICollection<Feedback> Feedbacks { get; set; } = new List<Feedback>();
} 