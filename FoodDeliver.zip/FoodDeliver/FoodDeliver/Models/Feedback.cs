using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FoodDeliver.Models;

public class Feedback
{
    [Key]
    public string Id { get; set; } = Guid.NewGuid().ToString();
    
    [Required]
    public string UserId { get; set; } = string.Empty;
    
    [Required]
    public string RestaurantId { get; set; } = string.Empty;
    
    public string? OrderId { get; set; }
    
    [Required]
    public string Message { get; set; } = string.Empty;
    
    public int? Rating { get; set; } // 1-5 stars
    
    [Required]
    public string Status { get; set; } = "new"; // new, resolved, flagged
    
    public string? Response { get; set; }
    
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    
    public DateTime? UpdatedAt { get; set; }
    
    // Navigation properties
    [ForeignKey("UserId")]
    public virtual User User { get; set; } = null!;
    
    [ForeignKey("RestaurantId")]
    public virtual Restaurant Restaurant { get; set; } = null!;
    
    [ForeignKey("OrderId")]
    public virtual Order? Order { get; set; }
} 